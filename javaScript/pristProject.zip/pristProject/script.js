// LIVER__________________________



document.querySelector('#lp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop').classList.add('visibleTop');

});
document.querySelector('#hp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom').classList.add('visibleBottom');
});






// CORTEX____________________________




document.querySelector('#cortexlp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom2').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop2').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop2').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop2').classList.add('visibleTop');

});
document.querySelector('#cortexhp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop2').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom2').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom2').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom2').classList.add('visibleBottom');
});



// TRACHEA_____________________________



document.querySelector('#trachealp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom3').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop3').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop3').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop3').classList.add('visibleTop');

});
document.querySelector('#tracheahp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop3').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom3').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom3').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom3').classList.add('visibleBottom');
});





// LUNG______________________________________




document.querySelector('#lunglp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom4').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop4').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop4').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop4').classList.add('visibleTop');

});
document.querySelector('#lunghp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop4').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom4').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom4').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom4').classList.add('visibleBottom');
});





// STOMACH___________________________________________




document.querySelector('#stomachlp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom5').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop5').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop5').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop5').classList.add('visibleTop');

});
document.querySelector('#stomachhp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop5').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom5').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom5').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom5').classList.add('visibleBottom');
});





// BLADDER__________________________________________________________-




document.querySelector('#bladderlp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom6').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop6').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop6').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop6').classList.add('visibleTop');

});
document.querySelector('#bladderhp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop6').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom6').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom6').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom6').classList.add('visibleBottom');
});






// ARTERY__________________________________________________________________






document.querySelector('#arterylp').addEventListener('click',function()
{
    document.querySelector('.hiddenBottom7').classList.remove('visibleBottom');
    if(document.querySelector('.hiddenTop7').classList.contains('visibleTop'))
    {
        document.querySelector('.hiddenTop7').classList.remove('visibleTop');
    }
    else
    document.querySelector('.hiddenTop7').classList.add('visibleTop');

});
document.querySelector('#arteryhp').addEventListener('click',function()
{
    document.querySelector('.hiddenTop7').classList.remove('visibleTop');
    if(document.querySelector('.hiddenBottom7').classList.contains('visibleBottom'))
    {
        document.querySelector('.hiddenBottom7').classList.remove('visibleBottom');
    }
    else
    document.querySelector('.hiddenBottom7').classList.add('visibleBottom');
});